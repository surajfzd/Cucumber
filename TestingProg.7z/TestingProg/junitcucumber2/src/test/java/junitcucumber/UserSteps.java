package junitcucumber;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junitcucumber.User;

public class UserSteps {

	private User user = new User();

	@Given("^that the user (.*) is given a task to book a ticket to (.*) city$")
	public void certificationName(String person, String place) throws Throwable {
		user.setPerson(person);
		user.setPlace(place);
	}

	@When("^(.*) books (\\d+) tickets$")
	public void gotMarks(String name, int tickets) throws Throwable {
		user.setPerson(name);
		user.setTickets(tickets);
	}

	@Then("^(.*) booked (.*) tickets successfully$")
	public void certifiedYes(String name, String certification) throws Throwable {
		assertThat(name, is(user.getPerson()));
		assertThat(user.getPlace(), equalTo("Agra"));
		assertThat(user.getResult(), is(true));
	}
}
