package junitcucumber;

public class User {

	private String person;
	private String place;
	private int tickets;

	public String getPerson() {
		return person;
	}

	public void setPerson(String person) {
		this.person = person;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public int getTickets() {
		return tickets;
	}

	public void setTickets(int tickets) {
		this.tickets = tickets;
	}

	public boolean getResult() {
		if (this.tickets < 4) {
			return false;
		} else {
			return true;
		}
	}

}
