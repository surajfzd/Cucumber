package junitcucumber;

public class User {

	private String person;
	private int personAge;
	private int age;

	
	public String getPerson() {
		return person;
	}


	public void setPerson(String person) {
		this.person = person;
	}
	


	public int getPersonAge() {
		return personAge;
	}


	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public boolean getResult() {
		if (this.personAge < this.age) {
			return false;
		} else {
			return true;
		}
	}
//	public boolean checkAge() {
//		if (this.personAge < 21) {
//			return false;
//		} else {
//			return true;
//		}
	
}