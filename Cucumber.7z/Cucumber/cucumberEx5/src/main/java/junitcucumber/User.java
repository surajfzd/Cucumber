package junitcucumber;

public class User {

	private String name;
	private String day;
	private String rating;

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDay() {
		return day;
	}


	public void setDay(String day) {
		this.day = day;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public boolean getResult() {
		if (this.rating.equals("C")) {
			return true;
		} else {
			return false;
		}
	}

}
