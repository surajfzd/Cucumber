package junitcucumber;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junitcucumber.User;

public class UserSteps {

	private User user = new User();

	@Given("^that the user (.*) is sleeping in office on (.*)$")
	public void certificationName(String name, String day) throws Throwable {
		user.setName(name);
		user.setDay(day);
	}

	@When("^(.*) got (.*) rating in appraisal$")
	public void gotMarks(String name, String rating) throws Throwable {
		user.setName(name);
		user.setRating(rating);
	}

	@Then("^(.*) is fired$")
	public void certifiedYes(String name) throws Throwable {
		assertThat(name, is(user.getName()));
		assertThat(user.getResult(), is(true));
	}
}
