package junitcucumber.exception;

public class MobilenumberIsNotFoundException extends Exception {

}
