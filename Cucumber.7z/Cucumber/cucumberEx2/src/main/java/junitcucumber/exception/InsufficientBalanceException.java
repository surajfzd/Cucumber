package junitcucumber.exception;

public class InsufficientBalanceException extends Exception {

}
