package junitcucumber.exception;

public class DupicateMobileNumberException extends Exception {

}
