package junitcucumber;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertEquals;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junitcucumber.User;

public class UserSteps {

	private User user = new User();

	@Given("^that the person (.*) is (\\d+) years old$")
	public void certificationName(String person, int personAge) throws Throwable {
		user.setPerson(person);
		user.setPersonAge(personAge);
	}

	@When("^person is (\\d+) years old$")
	public void gotMarks( int age) throws Throwable {
		user.setAge(age);
	}

	@Then("^(.*) is eligible to cast vote$")
	public void certifiedYes(String name) throws Throwable {
		assertThat(name, is(user.getPerson()));
		assertThat(user.getResult(), is(true));
	}
}
